@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Students List</h2>
    <a href="{{ route('students.create') }}">Add Student</a>
    <form method="GET" action="{{ route('students.index') }}">
        <input type="text" name="search" placeholder="Search by name">
    </form>
    <table>
        <tr>
            <th>Name</th><th>Email</th><th>Class</th><th>Section</th><th>Action</th>
        </tr>
        @foreach($students as $student)
        <tr>
            <td>{{ $student->name }}</td><td>{{ $student->email }}</td>
            <td>{{ $student->class }}</td><td>{{ $student->section }}</td>
            <td>
                <a href="{{ route('students.edit', $student) }}">Edit</a>
                <form action="{{ route('students.destroy', $student) }}" method="POST">
                    @csrf @method('DELETE')
                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
    {{ $students->links() }}
</div>
@endsection
